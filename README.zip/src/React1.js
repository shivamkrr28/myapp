function React1(){
    return(
        <>
        React Component
        </>
    );
}

export default React1;