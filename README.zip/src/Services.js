import React from 'react';

function Services(){

    return (
        <h1>Services Component</h1>
    ); 
}

export default Services;